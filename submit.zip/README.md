### **CURRENTLY BROKEN**
# Type Less Alma

Hotfix for barcode scanning problem for the UCLA Sciences Libraries.

**Note:** When your browser asks to turn off developer mode, do not do so and tell it to remind you in X weeks. I will upload it to the Edge developer
store soon so that the developer mode message will not appear again.

## Features
- Support for barcode scanning of chromebooks
- More to come...

## Support
For support, private message me on Slack! I'm also open to suggestions for new features and ideas to make our library front desk experience better!

